﻿namespace GSMInfo.Enumerations
{
	using System;

	public enum BatteryType
	{
		Li_Poly,
		Li_Ion,
		NiCd,
		NiMH
	}
}
