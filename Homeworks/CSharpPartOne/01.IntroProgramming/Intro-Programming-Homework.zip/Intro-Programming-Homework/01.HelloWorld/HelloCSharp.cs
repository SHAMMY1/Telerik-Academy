﻿//Problem 4. Hello World

//Create, compile and run a “Hello C#” console application.
//Ensure you have named the application well (e.g. “”HelloCSharp”).
//You should submit the Visual Studio project holding the HelloCSharp class as part of your homework.
using System;

class HelloCSharp
{
	static void Main()
	{
		string messageToPrint = "Hello C#";

		Console.WriteLine(messageToPrint);
	}
}


