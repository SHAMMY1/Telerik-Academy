﻿//Problem 6. Print Numbers

//Write a program to print the numbers 1, 101 and 1001, each at a separate line.
//Name the program correctly.
//You should submit in your homework the Visual Studio project holding the source code of the PrintNumbers program.
using System;

class PrintNumbers
{
	static void Main()
	{
		int firstNumber = 1;
		int secondNumber = 101;
		int thirdNumber = 1001;

		Console.WriteLine(firstNumber);
		Console.WriteLine(secondNumber);
		Console.WriteLine(thirdNumber);
	}
}

